package com.example.data

import android.util.Log
import com.example.ui.viewmodel.AppServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class FirestoreUserProfile(
    val username: String,
    val remainingGb: Float,
    val usedGb: Float,
    val totalQuotaGb: Float,
    val remainingDays: Int,
    val planType: String, // "MULTI_USER" or "SINGLE_USER"
    val maxDevices: Int,
    val activeDevices: Int,
    val expiryDate: String,
    val status: String = "ACTIVE",
    val password: String? = null
)

data class FirestoreGiftCode(
    val code: String,
    val bonusGb: Float,
    val bonusDays: Int,
    val description: String
)

data class FirestoreAppConfig(
    val telegramSupport: String,
    val channelUrl: String,
    val announcement: String
)

object FirestoreService {
    private const val TAG = "FirestoreService"
    
    // Cloudflare Worker Relay URL to bypass 403 sanctions in Iran
    private const val BASE_URL = "https://pingovpn.mpouanfar.workers.dev/v1/projects/suprotect-687cd/databases/(default)/documents"

    /**
     * Fetch user profile from Firestore /users/{username}
     */
    suspend fun fetchUserProfile(username: String): FirestoreUserProfile? = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/users/$username"
            val responseString = httpGet(endpoint) ?: return@withContext null
            val json = JSONObject(responseString)
            
            if (json.has("error")) {
                Log.w(TAG, "Firestore error fetching user $username: ${json.getJSONObject("error").optString("message")}")
                return@withContext null
            }

            val fields = json.optJSONObject("fields") ?: return@withContext null
            
            val remainingGb = extractNumber(fields, "remainingGb") ?: 34.1f
            val usedGb = extractNumber(fields, "usedGb") ?: 23.9f
            val totalQuotaGb = extractNumber(fields, "totalQuotaGb") ?: (remainingGb + usedGb)
            val remainingDays = extractInt(fields, "remainingDays") ?: 17
            val planType = extractString(fields, "planType") ?: "MULTI_USER"
            val maxDevices = extractInt(fields, "maxDevices") ?: (if (planType == "MULTI_USER") 2 else 1)
            val activeDevices = extractInt(fields, "activeDevices") ?: 1
            val expiryDate = extractString(fields, "expiryDate") ?: "۱۴۰۵/۰۷/۲۹"
            val status = extractString(fields, "status") ?: "ACTIVE"
            val password = extractString(fields, "password")

            FirestoreUserProfile(
                username = username,
                remainingGb = remainingGb,
                usedGb = usedGb,
                totalQuotaGb = totalQuotaGb,
                remainingDays = remainingDays,
                planType = planType,
                maxDevices = maxDevices,
                activeDevices = activeDevices,
                expiryDate = expiryDate,
                status = status,
                password = password
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch user profile", e)
            null
        }
    }

    /**
     * Fetch dynamic server list from Firestore /servers
     */
    suspend fun fetchServers(): List<AppServer>? = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/servers"
            val responseString = httpGet(endpoint) ?: return@withContext null
            val json = JSONObject(responseString)
            
            if (json.has("error")) {
                Log.w(TAG, "Firestore error fetching servers: ${json.getJSONObject("error").optString("message")}")
                return@withContext null
            }

            val documents = json.optJSONArray("documents") ?: return@withContext null
            val servers = mutableListOf<AppServer>()

            for (i in 0 until documents.length()) {
                val doc = documents.getJSONObject(i)
                val fields = doc.optJSONObject("fields") ?: continue
                
                val name = doc.optString("name")
                val docId = name.substringAfterLast("/")
                val country = extractString(fields, "country") ?: "سرور"
                val city = extractString(fields, "city") ?: "اصلی"
                val flag = extractString(fields, "flag") ?: "🌐"
                val host = extractString(fields, "host") ?: "8.8.8.8"
                val port = extractInt(fields, "port") ?: 443
                val badge = extractString(fields, "badge") ?: "A"
                val ping = extractInt(fields, "ping") ?: 45
                val isPro = extractBoolean(fields, "isPro") ?: false
                val configUri = extractString(fields, "configUri") ?: ""

                servers.add(
                    AppServer(
                        id = docId,
                        country = country,
                        city = city,
                        flag = flag,
                        host = host,
                        port = port,
                        ping = ping,
                        badge = badge,
                        isPro = isPro,
                        configUri = configUri
                    )
                )
            }
            if (servers.isNotEmpty()) servers else null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch servers", e)
            null
        }
    }

    /**
     * Sync user usage and remaining balance back to Firestore
     */
    suspend fun updateUserUsage(username: String, usedGb: Float, remainingGb: Float): Boolean = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/users/$username?updateMask.fieldPaths=usedGb&updateMask.fieldPaths=remainingGb"
            val payload = JSONObject().apply {
                put("fields", JSONObject().apply {
                    put("usedGb", JSONObject().apply { put("doubleValue", usedGb.toDouble()) })
                    put("remainingGb", JSONObject().apply { put("doubleValue", remainingGb.toDouble()) })
                })
            }
            httpPatch(endpoint, payload.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update user usage in Firestore", e)
            false
        }
    }

    /**
     * Update active devices count in Firestore (decremented on logout, incremented on login)
     */
    suspend fun updateUserActiveDevices(username: String, activeDevices: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/users/$username?updateMask.fieldPaths=activeDevices"
            val payload = JSONObject().apply {
                put("fields", JSONObject().apply {
                    put("activeDevices", JSONObject().apply { put("integerValue", activeDevices.toString()) })
                })
            }
            httpPatch(endpoint, payload.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update active devices in Firestore", e)
            false
        }
    }

    /**
     * Update quota when user redeems gift code
     */
    suspend fun updateUserQuota(username: String, remainingGb: Float, totalQuotaGb: Float, remainingDays: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/users/$username?updateMask.fieldPaths=remainingGb&updateMask.fieldPaths=totalQuotaGb&updateMask.fieldPaths=remainingDays"
            val payload = JSONObject().apply {
                put("fields", JSONObject().apply {
                    put("remainingGb", JSONObject().apply { put("doubleValue", remainingGb.toDouble()) })
                    put("totalQuotaGb", JSONObject().apply { put("doubleValue", totalQuotaGb.toDouble()) })
                    put("remainingDays", JSONObject().apply { put("integerValue", remainingDays.toString()) })
                })
            }
            httpPatch(endpoint, payload.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update quota in Firestore", e)
            false
        }
    }

    /**
     * Fetch gift code from Firestore
     */
    suspend fun fetchGiftCode(code: String): FirestoreGiftCode? = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/gift_codes/$code"
            val responseString = httpGet(endpoint) ?: return@withContext null
            val json = JSONObject(responseString)
            if (json.has("error")) return@withContext null
            val fields = json.optJSONObject("fields") ?: return@withContext null
            val active = extractBoolean(fields, "active") ?: true
            if (!active) return@withContext null
            val bonusGb = extractNumber(fields, "bonusGb") ?: 5.0f
            val bonusDays = extractInt(fields, "bonusDays") ?: 0
            val desc = extractString(fields, "description") ?: "کد هدیه فعال شد"
            FirestoreGiftCode(code, bonusGb, bonusDays, desc)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch gift code", e)
            null
        }
    }

    /**
     * Fetch app configuration (support telegram, announcement) from Firestore
     */
    suspend fun fetchAppConfig(): FirestoreAppConfig? = withContext(Dispatchers.IO) {
        try {
            val endpoint = "$BASE_URL/config/app"
            val responseString = httpGet(endpoint) ?: return@withContext null
            val json = JSONObject(responseString)
            if (json.has("error")) return@withContext null
            val fields = json.optJSONObject("fields") ?: return@withContext null
            val tg = extractString(fields, "telegramSupport") ?: "AlphaSupport_ir"
            val ch = extractString(fields, "channelUrl") ?: "https://t.me/AlphaSupport_ir"
            val ann = extractString(fields, "announcement") ?: ""
            FirestoreAppConfig(tg, ch, ann)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch app config", e)
            null
        }
    }

    // Helper functions for parsing Firestore typed fields:
    private fun extractString(fields: JSONObject, key: String): String? {
        val obj = fields.optJSONObject(key) ?: return null
        return obj.optString("stringValue", null)
    }

    private fun extractNumber(fields: JSONObject, key: String): Float? {
        val obj = fields.optJSONObject(key) ?: return null
        if (obj.has("doubleValue")) return obj.optDouble("doubleValue").toFloat()
        if (obj.has("integerValue")) return obj.optString("integerValue").toFloatOrNull()
        return null
    }

    private fun extractInt(fields: JSONObject, key: String): Int? {
        val obj = fields.optJSONObject(key) ?: return null
        if (obj.has("integerValue")) return obj.optString("integerValue").toIntOrNull()
        if (obj.has("doubleValue")) return obj.optDouble("doubleValue").toInt()
        return null
    }

    private fun extractBoolean(fields: JSONObject, key: String): Boolean? {
        val obj = fields.optJSONObject(key) ?: return null
        return obj.optBoolean("booleanValue", false)
    }

    private fun httpGet(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            conn.setRequestProperty("Accept", "application/json")
            
            val status = conn.responseCode
            val inputStream = if (status in 200..299) conn.inputStream else conn.errorStream
            if (inputStream == null) return null
            
            val reader = BufferedReader(InputStreamReader(inputStream))
            val sb = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                sb.append(line)
            }
            reader.close()
            sb.toString()
        } catch (e: Exception) {
            Log.e(TAG, "HTTP GET failed for $urlStr", e)
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpPatch(urlStr: String, jsonBody: String): Boolean {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            val status = conn.responseCode
            status in 200..299
        } catch (e: Exception) {
            Log.e(TAG, "HTTP PATCH failed for $urlStr", e)
            false
        } finally {
            conn?.disconnect()
        }
    }
}
